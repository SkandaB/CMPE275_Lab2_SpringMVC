# Java extending runtime sample for Google Managed VMs
This sample demonstrates how to use custom runtime on Google Managed VMs
## Setup
Before you can run this sample locally, you will have to edit the <writeable.directory> and <gcloud.sdk.directory> properties in the pom.xml
