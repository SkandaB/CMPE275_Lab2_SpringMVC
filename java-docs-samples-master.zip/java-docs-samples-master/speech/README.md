# Cloud Speech API samples for Java

This directory contains several samples for the [Cloud Speech API](https://cloud.google.com/speech/)
with Java.

- [grpc](grpc)

  A sample for accessing Cloud Speech streaming and non streaming apis with [gRPC](http://www.grpc.io/).
