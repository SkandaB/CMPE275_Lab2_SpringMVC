package edu.sjsu.cmpe275.lab2.Controller;

import org.springframework.stereotype.Service;

@Service
public class UserSerivce {

}
